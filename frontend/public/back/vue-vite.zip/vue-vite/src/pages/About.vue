<template>
  <div class="container p-3 text-center v-align">
    <h1>About Page</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>
</style>