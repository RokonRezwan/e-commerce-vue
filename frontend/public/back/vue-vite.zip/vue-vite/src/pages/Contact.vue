<template>
  <div class="container p-3 text-center v-align">
    <h1>Contact Page</h1>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>
